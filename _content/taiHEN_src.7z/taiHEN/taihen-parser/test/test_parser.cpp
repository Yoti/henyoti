#include <taihen/parser.h>

#define BOOST_TEST_MODULE parser
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(removed_for_now)
{

}
