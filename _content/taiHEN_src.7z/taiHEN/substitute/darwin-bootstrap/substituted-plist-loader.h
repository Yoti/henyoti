void get_bundle_list(const char *exec_name,
                     const void **bundle_list, size_t *bundle_list_size);
